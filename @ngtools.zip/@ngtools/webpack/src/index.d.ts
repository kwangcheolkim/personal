export * from './plugin';
export * from './extract_i18n_plugin';
export { ngcLoader as default } from './loader';
export { PathsPlugin } from './paths-plugin';
