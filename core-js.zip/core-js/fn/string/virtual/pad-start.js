require('../../../modules/es7.string.pad-start');
module.exports = require('../../../modules/_entry-virtual')('String').padStart;