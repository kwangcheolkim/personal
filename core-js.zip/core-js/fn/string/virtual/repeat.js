require('../../../modules/es6.string.repeat');
module.exports = require('../../../modules/_entry-virtual')('String').repeat;