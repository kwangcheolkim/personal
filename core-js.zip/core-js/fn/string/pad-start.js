require('../../modules/es7.string.pad-start');
module.exports = require('../../modules/_core').String.padStart;
