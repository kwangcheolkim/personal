require('../../modules/es6.string.blink');
module.exports = require('../../modules/_core').String.blink;