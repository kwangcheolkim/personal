require('../../modules/es7.reflect.define-metadata');
module.exports = require('../../modules/_core').Reflect.defineMetadata;