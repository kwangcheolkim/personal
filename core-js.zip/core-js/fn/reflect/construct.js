require('../../modules/es6.reflect.construct');
module.exports = require('../../modules/_core').Reflect.construct;