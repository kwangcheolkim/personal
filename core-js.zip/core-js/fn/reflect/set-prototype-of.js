require('../../modules/es6.reflect.set-prototype-of');
module.exports = require('../../modules/_core').Reflect.setPrototypeOf;