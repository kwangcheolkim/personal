require('../../modules/es7.object.define-setter');
module.exports = require('../../modules/_core').Object.__defineSetter__;