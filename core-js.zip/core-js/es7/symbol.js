require('../modules/es7.symbol.async-iterator');
require('../modules/es7.symbol.observable');
module.exports = require('../modules/_core').Symbol;