"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getDevConfig = function (_wco) {
    return {};
};
//# sourceMappingURL=/users/hansl/sources/angular-cli/models/webpack-configs/development.js.map