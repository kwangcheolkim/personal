export declare const getWebpackExtractI18nConfig: (projectRoot: string, appConfig: any, genDir: string, i18nFormat: string, locale: string, outFile: string) => any;
