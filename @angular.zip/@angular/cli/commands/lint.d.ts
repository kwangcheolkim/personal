export interface LintCommandOptions {
    fix?: boolean;
    format?: string;
    force?: boolean;
}
declare var _default: any;
export default _default;
